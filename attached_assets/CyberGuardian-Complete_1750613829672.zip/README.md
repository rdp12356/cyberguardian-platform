# CyberGuardian

1. `npm install`
2. Add your .env file
3. `npm run dev` to start